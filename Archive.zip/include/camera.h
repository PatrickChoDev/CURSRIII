#include <Arduino.h>
#include <camera.hpp>
#include <radio.hpp>