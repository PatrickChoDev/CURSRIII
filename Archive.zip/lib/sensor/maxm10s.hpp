#ifndef MAXM10S_HPP
#define MAXM10S_HPP
#include <sensor.hpp>

#endif

#ifndef MAXM10S_ENABLED
#define MAXM10S_ENABLED 1
#endif