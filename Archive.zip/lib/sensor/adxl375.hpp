#include <sensor.hpp>

#ifndef ADXL375_ENABLED
#define ADXL375_ENABLED 1
#endif
