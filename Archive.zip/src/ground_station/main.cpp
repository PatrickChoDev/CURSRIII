#include <Arduino.h>

void loop() {}

void setup()
{
  Serial.begin(115200);
}