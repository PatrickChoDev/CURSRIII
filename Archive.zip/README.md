# CURSR-III

This repository contains code of CURSR-III, CUHAR's sounding rocket.

© PatrickChodev 2024

